package com.example.kumarshubham.stayfit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class home extends AppCompatActivity {

    Button login,singup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
               setContentView(R.layout.home);


               login=findViewById(R.id.home_login);
               singup=findViewById(R.id.home_signup);


               login.setOnClickListener(new View.OnClickListener() {
                   @Override
                   public void onClick(View view) {
                       Intent intent = new Intent(home.this, Login_form.class);
                       startActivity(intent);
                   }
               });

               singup.setOnClickListener(new View.OnClickListener() {
                   @Override
                   public void onClick(View v) {
                       Intent intent = new Intent(home.this, SignUp_form.class);
                       startActivity(intent);
                   }
               });
    }


}
